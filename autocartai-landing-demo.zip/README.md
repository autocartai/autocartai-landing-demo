# AutoKart.ai Landing Page

A basic landing page for the AI-powered dropshipping platform AutoKart.ai.